#!/usr/bin/python
# -*- coding: utf-8 -*-

# Import the modules
import os, time, random, string, sys, platform
import xbmc, xbmcaddon, xbmcgui, xbmcvfs
from threading import Thread

try:
    from urllib.request import build_opener, HTTPPasswordMgrWithDefaultRealm, HTTPBasicAuthHandler, HTTPDigestAuthHandler, Request
except ImportError:
    from urllib2 import build_opener, HTTPPasswordMgrWithDefaultRealm, HTTPBasicAuthHandler, HTTPDigestAuthHandler, Request

# Constants
ACTION_PREVIOUS_MENU = 10
ACTION_STOP = 13
ACTION_NAV_BACK = 92
ACTION_BACKSPACE = 110


MAXCAMS = 9

# Set plugin variables
__addon__        = xbmcaddon.Addon()
__addon_id__     = __addon__.getAddonInfo('id')
__addon_path__   = __addon__.getAddonInfo('path')
__profile__      = __addon__.getAddonInfo('profile')
__black__        = os.path.join(__addon_path__, 'resources', 'media', 'black.png')
__loading__      = os.path.join(__addon_path__, 'resources', 'media', 'loading.gif')
__settings__     = os.path.join(__profile__, 'settings.xml')

CAMERAS          = []

ffmpeg_exec      = 'ffmpeg.exe' if platform.system() == 'Windows' else 'ffmpeg'

# Utils
def log(message,loglevel=xbmc.LOGNOTICE):
    xbmc.log(msg='[{}] {}'.format(__addon_id__, message), level=loglevel)


def which(pgm):
    for path in os.getenv('PATH').split(os.path.pathsep):
        p=os.path.join(path, pgm)
        if os.path.exists(p) and os.access(p, os.X_OK):
            return p
    return None

# Classes
class CamPreviewDialog(xbmcgui.WindowDialog):
    def __init__(self, cameras):
        self.threads  = []

        self.total    = len(cameras)
        self.cams     = cameras

        passwd_mgr = HTTPPasswordMgrWithDefaultRealm()
        self.opener = build_opener()

        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, __black__))

        for i in range(self.total):
            if self.cams[i]['username'] and self.cams[i]['password']:
                passwd_mgr.add_password(None, self.cams[i]['url'], self.cams[i]['username'], self.cams[i]['password'])
                self.opener.add_handler(HTTPBasicAuthHandler(passwd_mgr))
                self.opener.add_handler(HTTPDigestAuthHandler(passwd_mgr))

            randomname = ''.join([random.choice(string.ascii_letters + string.digits) for n in range(32)])
            self.cams[i]['tmpdir'] = os.path.join(__profile__, randomname)
            if not xbmcvfs.exists(self.cams[i]['tmpdir']):
                xbmcvfs.mkdir(self.cams[i]['tmpdir'])

            if not SETTINGS['customGrid']:
                self.cams[i]['x'], self.cams[i]['y'], self.cams[i]['width'], self.cams[i]['height'] = self.coordinates(self.total, i)

            self.cams[i]['control'] = xbmcgui.ControlImage(
                self.cams[i]['x'], self.cams[i]['y'], self.cams[i]['width'], self.cams[i]['height'],
                __loading__, aspectRatio = self.cams[i]['aspectRatio'])
            self.addControl(self.cams[i]['control'])


    def coordinates(self, total, position):
        grid_coords = [
                  [(320,180,640,360)],
                  [(0,180,640,360),(640,180,640,360)],
                  [(0,0,640,360),(640,0,640,360),(180,360,640,360)],
                  [(0,0,640,360),(640,0,640,360),(0,360,640,360),(640,360,640,360)],
                  [(0,120,427,240),(427,120,427,240),(854,120,427,240),(214,360,427,240),(640,360,427,240)],
                  [(0,120,427,240),(427,120,427,240),(854,120,427,240),(0,360,427,240),(427,360,427,240),(854,360,427,240)],
                  [(0,0,427,240),(427,0,427,240),(854,0,427,240),(214,240,427,240),(640,240,427,240),(214,480,427,240),(640,480,427,240)],
                  [(0,0,427,240),(427,0,427,240),(854,0,427,240),(0,240,427,240),(427,240,427,240),(854,240,427,240),(214,480,427,240),(640,480,427,240)],
                  [(0,0,427,240),(427,0,427,240),(854,0,427,240),(0,240,427,240),(427,240,427,240),(854,4800,427,240),(0,480,427,240),(427,480,427,240),(854,480,427,240)]
                  ]

        return grid_coords[total - 1][position]


    def start(self):
        self.show()
        self.isRunning = True

        for i in range(self.total):
            t = Thread(target=self.update, args=(self.cams[i],))
            #t.daemon = True  # This thread dies when main thread (only non-daemon thread) exits.
            t.start()
            self.threads.append(t)

        startTime = time.time()
        while(not SETTINGS['autoClose'] or (time.time() - startTime) * 1000 <= SETTINGS['duration']):
            if not self.isRunning:
                 break
            xbmc.sleep(500)

        self.isRunning = False

        self.close()
        self.cleanup()


    def update(self, cam):
        request = Request(cam['url'])
        old_snapshot = None
        index = 1

        type = cam['url'][:4]

        if type == 'rtsp':
            if not which(ffmpeg_exec):
                log('Error: {} not installed. Can\'t process rtsp input format.'.format(ffmpeg_exec))
                #self.isRunning = False
                self.stop()
                return

            if cam['username'] and cam['password']:
                input = 'rtsp://{}:{}@{}'.format(cam['username'], cam['password'], cam['url'][7:])
            else:
                input = cam['url']

            output = os.path.join(cam['tmpdir'], 'snapshot_%06d.jpg')
            command = [ffmpeg_exec,
                      '-nostdin',
                      '-rtsp_transport', 'tcp',
                      '-i', input,
                      '-an',
                      '-f', 'image2',
                      '-vf', 'fps=fps='+str(int(1000.0/SETTINGS['interval'])),
                      '-q:v', '10',
                      '-s', str(cam['width'])+'x'+str(cam['height']),
                      '-vcodec', 'mjpeg',
                      xbmc.translatePath(output)]
            p = subprocess.Popen(command)

        while(self.isRunning):
            snapshot = os.path.join(cam['tmpdir'], 'snapshot_{:06d}.jpg'.format(index))
            if index > 1:
                old_snapshot = os.path.join(cam['tmpdir'], 'snapshot_{:06d}.jpg'.format(index - 1))
            index += 1

            try:
                if type == 'http':
                    imgData = self.opener.open(request).read()

                    if imgData:
                        file = xbmcvfs.File(snapshot, 'wb')
                        file.write(bytearray(imgData))
                        file.close()

                elif type == 'rtsp':
                    while(self.isRunning):
                        if xbmcvfs.exists(snapshot):
                            break
                        xbmc.sleep(10)

                elif xbmcvfs.exists(cam['url']):
                    xbmcvfs.copy(cam['url'], snapshot)

            except Exception as e:
                log(str(e))
                #snapshot = __loading__
                snapshot = None

            #if snapshot and xbmcvfs.exists(snapshot):
            if snapshot:
                cam['control'].setImage(snapshot, False)

            if old_snapshot:
                xbmcvfs.delete(old_snapshot)

            if type != 'rtsp':
                xbmc.sleep(SETTINGS['interval'])

        if type == 'rtsp' and p.pid:
            p.terminate()


    def cleanup(self):
        for t in self.threads:
            del t

        for i in range(self.total):
            files = xbmcvfs.listdir(self.cams[i]['tmpdir'])[1]
            for file in files:
                xbmcvfs.delete(os.path.join(self.cams[i]['tmpdir'], file))
            xbmcvfs.rmdir(self.cams[i]['tmpdir'])


    def onAction(self, action):
        if action in (ACTION_PREVIOUS_MENU, ACTION_STOP, ACTION_BACKSPACE, ACTION_NAV_BACK):
            self.stop()


    def stop(self):
        self.isRunning = False


if __name__ == '__main__':
    if not xbmcvfs.exists(__settings__):
        xbmc.executebuiltin('Addon.OpenSettings(' + __addon_id__ + ')')

    # Get settings
    SETTINGS = {
        'interval':     int(float(__addon__.getSetting('interval'))),
        'autoClose':    bool(__addon__.getSetting('autoClose') == 'true'),
        'duration':     int(float(__addon__.getSetting('duration')) * 1000),
        'customGrid':   bool(__addon__.getSetting('customGrid') == 'true')
        }

    for i in range(MAXCAMS):
        if __addon__.getSetting('active{:d}'.format(i + 1)) == 'true':
            cam = {
                'url':          __addon__.getSetting('url{:d}'.format(i + 1)),
                'username':     __addon__.getSetting('username{:d}'.format(i + 1)),
                'password':     __addon__.getSetting('password{:d}'.format(i + 1)),
                'aspectRatio':  int(float(__addon__.getSetting('aspectRatio{:d}'.format(i + 1)))),
                'x':            int(float(__addon__.getSetting('posx{:d}'.format(i + 1)))),
                'y':            int(float(__addon__.getSetting('posy{:d}'.format(i + 1)))),
                'width':        int(float(__addon__.getSetting('width{:d}'.format(i + 1)))),
                'height':       int(float(__addon__.getSetting('height{:d}'.format(i + 1))))
                }
            CAMERAS.append(cam)

    camPreview = CamPreviewDialog(CAMERAS)
    camPreview.start()

    del camPreview
