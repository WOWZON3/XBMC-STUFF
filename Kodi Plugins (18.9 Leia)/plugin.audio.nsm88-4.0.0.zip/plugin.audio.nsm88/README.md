<p align="center"><img src="https://raw.githubusercontent.com/RAConquista/plugin.audio.nsm88/master/docs/images/NSM_Logo_500px.png"></p>
<br>
<br>
Ein Musik Addon für das XB Media Center. Mit diesem Plugin bekommt man Zugriff auf eine riesige RAC Musik Bibliothek welche aktuelle Musik Alben sowie Raritäten aus den verschiedensten Bereichen umfasst. Alle Titel sind in 320 kBits verfügbar.
<br>
<br>
<br>
<p align="center"><img src="https://raw.githubusercontent.com/RAConquista/plugin.audio.nsm88/master/docs/images/Blutlinie.png"></p>
<b>Latest Changes: 03.02.2021</b> 
<br>
<br>
<p align="center"><a href="https://github.com/RAConquista/plugin.audio.nsm88/archive/master.zip">plugin.audio.nsm88.zip</a>
<li>Umlaute wurden Korrigiert sowie zahlreiche neue Alben hinzugefügt. Die toten Google Drive Links wurden ersetzt und die Entsprechenden Alben sind somit wieder verfügbar.</li>
<br>
<li>Blue Eyed Devils: Holocaust 2000</li>
<li>Blutbanner: Sapere Aude (2015)</li>
<li>Blue Eyed Devils & Aggravated Assault: Hate Crimes</li>
<li>Blutlinie: Berserkerschmiede/Generation 3.0</li>

<li>Ultima Thule: Charlataner</li>
<li>Snöfried: Same</li>
<li>Confident Of Victory: Bis zum Horizont</li>
<li>Brigade 66: Entscheidung</li>
<li>Lass Leben: Nordwärts</li>
<li>I.C.1: Truth Will Out!</li>
<li>Old Lu & die Mississippi Lynchkapelle: Weisser Outlaw</li>
<li>Burning Hate: Warmachine</li>
<li>Phönix: Pflichterfüllung</li>
<li>Antithese - Befreiungskampf</li>
<li>Volksblut - Liebe | Leben | Vaterland</li>
<li>Gigi in Musica: 25 Jahre</li>
<li>Gigi & Die Braunen Stadtmusikanten: Was Von Meinungsfreiheit Bleibt</li>
<li>Barking Dogs: Dein Tag</li>
<li>Barking Dogs: Herzlich Willkommen im Niemandsland</li>
<li>Blutrein: Naturkampf</li>
<li>Uwocaust & alte Freunde: Blutgruppe</li>
<li>Jan Peter: Echoes from the Past</li>
<li>Ian Stuart: No Turning Back</li>
<li>Ian Stuart: Slay the Beast</li>
<li>Panzerfaust: Musik im Zeichen der weissen Faust</li>
<li>HKL: Ultranational</li>
<li>N´Socialist Soundsystem: Linientreu Und Angriffslustig</li>
<li>Die Weissen Riesen: Todesstrafe</li>
<br>
<br>
<h3>Screens:</h3>
<br>
<p align="center"><img src="https://raw.githubusercontent.com/RAConquista/plugin.audio.nsm88/master/docs/images/nsm_01.png"> <img src="https://raw.githubusercontent.com/RAConquista/plugin.audio.nsm88/master/docs/images/nsm_02.png"> <img src="https://raw.githubusercontent.com/RAConquista/plugin.audio.nsm88/master/docs/images/nsm_03.png"></p>
